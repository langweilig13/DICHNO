"""Compare the 36-characteristic adaptive group LASSO with paper Table 4.

This is a research approximation: the public CSV lacks the paper's last month
and security-type flags. The input is never modified.
"""

import argparse
import csv
import json
import time
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

from src.model.baseline_model import build_matrix


PAPER_14 = {
    "a2me", "at", "beta", "d2a", "e2p", "fc2y", "idio_vol",
    "lme", "lturnover", "rel_to_high_price", "cum_return_12_2",
    "cum_return_1_0", "cum_return_36_13", "sga2m", "suv",
}
PAPER_9 = PAPER_14 | {"c", "free_cf", "cum_return_12_7", "spread_mean"}


def load_data(path, price_filter="current"):
    if price_filter not in {"current", "previous"}:
        raise ValueError("price_filter must be 'current' or 'previous'")
    columns = pd.read_csv(path, nrows=0).columns.tolist()
    features = columns[10:]
    if len(features) != 36:
        raise ValueError(f"Expected 36 characteristics, found {len(features)}")
    wanted = ["yy", "mm", "prc", "ret", *features]
    if price_filter == "previous":
        wanted.append("permno")
    dtypes = {name: "float32" for name in wanted}
    dtypes.update({"yy": "int16", "mm": "int8"})
    if price_filter == "previous":
        dtypes["permno"] = "int32"
    data = pd.read_csv(path, usecols=wanted, dtype=dtypes)
    period = data.yy.to_numpy(dtype=np.int32) * 100 + data.mm.to_numpy(dtype=np.int32)
    if price_filter == "previous":
        data.sort_values(["permno", "yy", "mm"], kind="stable", inplace=True)
        month_index = data.yy.to_numpy(dtype=np.int32) * 12 + data.mm.to_numpy(dtype=np.int32)
        groups = data.groupby("permno", sort=False)
        previous_month = groups.yy.shift().to_numpy() * 12 + groups.mm.shift().to_numpy()
        eligible_price = (month_index == previous_month + 1) & (groups.prc.shift().abs().to_numpy() > 5)
        period = data.yy.to_numpy(dtype=np.int32) * 100 + data.mm.to_numpy(dtype=np.int32)
    else:
        eligible_price = data.prc.abs().to_numpy() > 5
    valid = (period >= 196307) & (period <= 201405) & eligible_price
    valid &= np.isfinite(data[["ret", *features]].to_numpy()).all(axis=1)
    data = data.loc[valid].copy()
    if price_filter == "previous":
        data.drop(columns="permno", inplace=True)
    return features, data


def load_risk_free(path):
    rates = {}
    with zipfile.ZipFile(path) as archive:
        name = next(name for name in archive.namelist() if name.lower().endswith(".csv"))
        with archive.open(name) as stream:
            for row in csv.reader(line.decode("utf-8-sig") for line in stream):
                if len(row) >= 5 and row[0].strip().isdigit() and len(row[0].strip()) == 6:
                    rates[int(row[0])] = float(row[4]) / 100
    return rates


def sufficient_statistics(data, features, knots, target, risk_free):
    group_size = len(knots) + 2  # The constant basis term is absorbed by the intercept.
    p = len(features) * group_size
    gram = np.zeros((p, p), dtype=np.float64)
    cross = np.zeros(p, dtype=np.float64)
    y2 = 0.0
    sum_basis = np.zeros(p, dtype=np.float64)
    sum_y = 0.0
    n = 0
    months = 0
    started = time.monotonic()
    for (year, month), frame in data.groupby(["yy", "mm"], sort=True):
        X = frame[features].to_numpy(dtype=np.float64)
        y = frame.ret.to_numpy(dtype=np.float64)
        # build_matrix performs the paper's cross-sectional rank normalization.
        basis = build_matrix(X, knots).reshape(len(frame), len(features), group_size + 1)
        basis = basis[:, :, 1:].reshape(len(frame), p)
        if target == "demeaned":
            basis -= basis.mean(axis=0)
            y -= y.mean()  # Demeaning also removes the month's risk-free return.
        else:
            key = int(year) * 100 + int(month)
            if key not in risk_free:
                raise ValueError(f"Missing risk-free rate for {key}")
            y -= risk_free[key]
        gram += basis.T @ basis
        cross += basis.T @ y
        y2 += float(y @ y)
        sum_basis += basis.sum(axis=0)
        sum_y += float(y.sum())
        n += len(frame)
        months += 1
        if months % 60 == 0:
            print(f"Built {months} months, {n:,} observations, {time.monotonic()-started:.0f}s", flush=True)
    gram = (gram - np.outer(sum_basis, sum_basis) / n) / n
    cross = (cross - sum_basis * sum_y / n) / n
    y2 = (y2 - sum_y * sum_y / n) / n
    return gram, cross, y2, n, months


def objective(beta, gram, cross, y2, penalty, weights):
    groups = beta.reshape(len(weights), -1)
    finite = np.isfinite(weights)
    return (0.5 * (y2 - 2 * beta @ cross + beta @ gram @ beta)
            + penalty * np.sum(weights[finite] * np.linalg.norm(groups[finite], axis=1)))


def fit_group_lasso(gram, cross, penalty, weights, initial, max_iter):
    """Block coordinate descent; solve each active group's convex subproblem."""
    groups, width = len(weights), len(cross) // len(weights)
    beta = initial.copy()
    residual = cross - gram @ beta
    blocks = []
    for group in range(groups):
        sl = slice(group * width, (group + 1) * width)
        if np.isfinite(weights[group]):
            eigenvalues, eigenvectors = np.linalg.eigh(gram[sl, sl])
            blocks.append((sl, np.maximum(eigenvalues, 0), eigenvectors))
        else:
            blocks.append((sl, None, None))
    for iteration in range(1, max_iter + 1):
        for group, (sl, eigenvalues, eigenvectors) in enumerate(blocks):
            if eigenvalues is None:
                continue
            group_cross = residual[sl] + gram[sl, sl] @ beta[sl]
            threshold = penalty * weights[group]
            if np.linalg.norm(group_cross) <= threshold:
                updated = np.zeros(width)
            else:
                rotated = eigenvectors.T @ group_cross
                low, high = 0.0, 1.0
                def root_value(alpha):
                    return alpha * np.linalg.norm(rotated / (eigenvalues + alpha))
                while root_value(high) < threshold:
                    high *= 2
                for _ in range(40):
                    mid = (low + high) / 2
                    if root_value(mid) < threshold:
                        low = mid
                    else:
                        high = mid
                updated = eigenvectors @ (rotated / (eigenvalues + high))
            change = updated - beta[sl]
            if np.any(change):
                beta[sl] = updated
                residual -= gram[:, sl] @ change
        if iteration % 5 == 0 and kkt_violation(beta, gram, cross, penalty, weights) < 0.001:
            break
    return beta, iteration


def mse_from_stats(beta, gram, cross, y2):
    return max(float(y2 - 2 * beta @ cross + beta @ gram @ beta), np.finfo(float).tiny)


def kkt_violation(beta, gram, cross, penalty, weights):
    groups = len(weights)
    vectors = beta.reshape(groups, -1)
    gradient = (gram @ beta - cross).reshape(groups, -1)
    violations = []
    for group in range(groups):
        norm = np.linalg.norm(vectors[group])
        if norm > 1e-8:
            violations.append(np.linalg.norm(gradient[group] + penalty * weights[group] * vectors[group] / norm))
        elif np.isfinite(weights[group]):
            violations.append(max(0.0, np.linalg.norm(gradient[group]) - penalty * weights[group]))
    return float(max(violations, default=0.0) / max(penalty, np.finfo(float).tiny))


def effective_degrees_of_freedom(beta, gram, penalty, weights):
    """Local group-LASSO degrees of freedom for a correlated spline design."""
    groups = len(weights)
    width = len(beta) // groups
    vectors = beta.reshape(groups, width)
    active = np.flatnonzero(np.linalg.norm(vectors, axis=1) > 1e-8)
    if not len(active):
        return 0.0
    columns = np.concatenate([np.arange(group * width, (group + 1) * width) for group in active])
    subgram = gram[np.ix_(columns, columns)]
    hessian = subgram.copy()
    identity = np.eye(width)
    for position, group in enumerate(active):
        vector = vectors[group]
        norm = np.linalg.norm(vector)
        block = slice(position * width, (position + 1) * width)
        hessian[block, block] += penalty * weights[group] * (
            identity / norm - np.outer(vector, vector) / norm**3
        )
    try:
        response = np.linalg.solve(hessian, subgram)
    except np.linalg.LinAlgError:
        response = np.linalg.lstsq(hessian, subgram, rcond=1e-10)[0]
    return float(np.trace(response))


def select_by_bic(gram, cross, y2, n, weights, max_iter, df_method,
                  steps=24, min_fraction=0.001):
    groups = len(weights)
    width = len(cross) // groups
    finite = np.isfinite(weights)
    cross_norms = np.linalg.norm(cross.reshape(groups, width), axis=1)
    lambda_max = float(np.max(cross_norms[finite] / weights[finite]))
    beta = np.zeros(len(cross), dtype=np.float64)
    best_bic = np.inf
    best_beta = None
    candidates = []
    for fraction in np.geomspace(1, min_fraction, steps):
        penalty = lambda_max * fraction
        beta, iterations = fit_group_lasso(gram, cross, penalty, weights, beta, max_iter)
        norms = np.linalg.norm(beta.reshape(groups, width), axis=1)
        active = norms > 1e-8
        mse = mse_from_stats(beta, gram, cross, y2)
        if df_method == "local":
            df = effective_degrees_of_freedom(beta, gram, penalty, weights)
        else:
            df = float(int(active.sum()) * width)
        bic = n * np.log(mse) + df * np.log(n)
        candidates.append({"lambda_fraction": float(fraction), "selected": int(active.sum()),
                           "selected_group_indices": np.flatnonzero(active).tolist(),
                           "effective_df": df, "bic": float(bic), "mse": mse,
                           "iterations": iterations,
                           "relative_kkt_violation": kkt_violation(beta, gram, cross, penalty, weights)})
        if bic < best_bic:
            best_bic, best_beta = bic, beta.copy()
    return best_beta, candidates


def ols_refit(gram, cross, y2, beta, groups):
    width = len(beta) // groups
    active = np.flatnonzero(np.linalg.norm(beta.reshape(groups, width), axis=1) > 1e-8)
    columns = np.concatenate([np.arange(group * width, (group + 1) * width) for group in active]) if len(active) else np.array([], dtype=int)
    refit = np.zeros_like(beta)
    if len(columns):
        refit[columns] = np.linalg.lstsq(gram[np.ix_(columns, columns)], cross[columns], rcond=1e-10)[0]
    return active, refit, mse_from_stats(refit, gram, cross, y2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, default=Path("data/characteristics_data_feb2017.csv"))
    parser.add_argument("--knots", type=int, choices=(9, 14), default=14)
    parser.add_argument("--bic-df", choices=("full", "local"), default="full")
    parser.add_argument("--target", choices=("excess", "demeaned"), default="excess")
    parser.add_argument("--rf-zip", type=Path, default=Path("data/F-F_Research_Data_Factors_CSV.zip"))
    parser.add_argument("--max-iter", type=int, default=50000)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output or Path(f"results/paper_comparison_{args.knots}knots_{args.bic_df}_{args.target}.json")
    knots = [i / (args.knots + 1) for i in range(1, args.knots + 1)]
    features, data = load_data(args.csv)
    print(f"Filtered sample: {len(data):,} observations", flush=True)
    risk_free = load_risk_free(args.rf_zip) if args.target == "excess" else {}
    gram, cross, y2, n, months = sufficient_statistics(data, features, knots,
                                                        args.target, risk_free)
    del data

    initial_weights = np.ones(len(features), dtype=np.float64)
    stage1, grid1 = select_by_bic(gram, cross, y2, n, initial_weights,
                                   args.max_iter, args.bic_df)
    group_size = args.knots + 2
    norms1 = np.linalg.norm(stage1.reshape(len(features), group_size), axis=1)
    stage2_weights = np.full(len(features), np.inf)
    positive = norms1 > 1e-8
    # Paper equation (6): (sum_k beta_sk^2)^(-1/2) = 1 / ||beta_s||_2.
    stage2_weights[positive] = 1 / norms1[positive]
    if positive.any():
        stage2, grid2 = select_by_bic(gram, cross, y2, n, stage2_weights,
                                       args.max_iter, args.bic_df)
    else:
        stage2, grid2 = stage1.copy(), []
    active, refit, refit_mse = ols_refit(gram, cross, y2, stage2, len(features))
    chosen = {features[i] for i in active}
    paper = PAPER_14 if args.knots == 14 else PAPER_9
    result = {
        "source_csv": str(args.csv),
        "period": "1963-07 through 2014-05",
        "price_filter": "abs(prc) > 5",
        "observations": n,
        "months": months,
        "paper_observations": 1073060,
        "characteristics": len(features),
        "knots": args.knots,
        "method": "monthly cross-sectional ranks; group LASSO/BIC; adaptive weighted group LASSO/BIC; OLS refit",
        "target": args.target,
        "risk_free_source": "https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Research_Data_Factors_CSV.zip" if args.target == "excess" else None,
        "bic_definition": f"n*log(MSE) + {args.bic_df}_degrees_of_freedom*log(n)",
        "stage1_selected": [features[i] for i in np.flatnonzero(positive)],
        "stage2_selected": sorted(chosen),
        "paper_selected": sorted(paper),
        "overlap": sorted(chosen & paper),
        "ours_only": sorted(chosen - paper),
        "paper_only": sorted(paper - chosen),
        "ols_refit_mse": refit_mse,
        "stage1_bic_grid": grid1,
        "stage2_bic_grid": grid2,
        "stage1_bic_at_grid_edge": bool(grid1 and min(grid1, key=lambda item: item["bic"]) is grid1[-1]),
        "stage1_solver_converged": min(grid1, key=lambda item: item["bic"])["relative_kkt_violation"] < 0.001,
        "stage2_solver_converged": bool(grid2 and min(grid2, key=lambda item: item["bic"])["relative_kkt_violation"] < 0.001),
        "limits": ["June 2014 and security-type flags are absent from the CSV.",
                   "The paper's exact BIC tuning implementation is unavailable; compare the full and local degrees-of-freedom options.",
                   "If stage1_bic_at_grid_edge is true, adaptive weights are sensitive to the lower penalty bound."],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(f"Wrote {output}; selected {len(chosen)}; overlap with paper {len(chosen & paper)}", flush=True)


if __name__ == "__main__":
    main()
