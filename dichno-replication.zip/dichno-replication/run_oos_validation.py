"""Rolling Table 5-style test: spline model and simple linear comparators."""

import argparse
import csv
import json
import zipfile
from collections import deque
from pathlib import Path

import numpy as np

from run_paper_comparison import (
    load_data, load_risk_free, select_by_bic, sufficient_statistics,
)
from src.model.baseline_model import build_matrix


def read_factors(path):
    factors = {}
    with zipfile.ZipFile(path) as archive:
        name = next(name for name in archive.namelist() if name.lower().endswith(".csv"))
        with archive.open(name) as stream:
            for row in csv.reader(line.decode("utf-8-sig") for line in stream):
                if len(row) >= 5 and row[0].strip().isdigit() and len(row[0].strip()) == 6:
                    factors[int(row[0])] = np.array([float(value) / 100 for value in row[1:4]])
    return factors


def make_design(frame, features, knots, model, center=None, scale=None):
    X = frame[features].to_numpy(dtype=np.float64)
    if model == "linear":
        return (X - center) / scale
    if model == "linear_rank":
        from src.transforms.ranking import rank_transform
        return np.column_stack([rank_transform(X[:, j]) for j in range(X.shape[1])])
    width = len(knots) + 2
    design = build_matrix(X, knots).reshape(len(frame), len(features), width + 1)
    return design[:, :, 1:].reshape(len(frame), len(features) * width)


def month_data(frame, features, knots, rf, model="np", center=None, scale=None):
    key = int(frame.yy.iloc[0]) * 100 + int(frame.mm.iloc[0])
    design = make_design(frame, features, knots, model, center, scale)
    raw_returns = frame.ret.to_numpy(dtype=np.float64)
    excess_returns = raw_returns - rf[key]
    return key, design, raw_returns, excess_returns


def monthly_sums(design, excess_returns):
    return {
        "n": len(excess_returns),
        "sum_z": design.sum(axis=0),
        "sum_y": float(excess_returns.sum()),
        "gram": design.T @ design,
        "cross": design.T @ excess_returns,
        "y2": float(excess_returns @ excess_returns),
    }


def linear_sufficient_statistics(data, features, knots, rf, model, center, scale):
    width = len(features)
    n, months, sum_y, y2 = 0, 0, 0.0, 0.0
    sum_z = np.zeros(width)
    gram = np.zeros((width, width))
    cross = np.zeros(width)
    for _, frame in data.groupby(["yy", "mm"], sort=True):
        _, design, _, excess = month_data(frame, features, knots, rf, model, center, scale)
        sums = monthly_sums(design, excess)
        n += sums["n"]
        months += 1
        sum_y += sums["sum_y"]
        sum_z += sums["sum_z"]
        gram += sums["gram"]
        cross += sums["cross"]
        y2 += sums["y2"]
    gram = (gram - np.outer(sum_z, sum_z) / n) / n
    cross = (cross - sum_z * sum_y / n) / n
    y2 = (y2 - sum_y * sum_y / n) / n
    return gram, cross, y2, n, months


def window_coefficients(window, width):
    n = sum(item["n"] for item in window)
    sum_z = sum((item["sum_z"] for item in window), np.zeros(width))
    sum_y = sum(item["sum_y"] for item in window)
    gram = sum((item["gram"] for item in window), np.zeros((width, width)))
    cross = sum((item["cross"] for item in window), np.zeros(width))
    centered_gram = gram - np.outer(sum_z, sum_z) / n
    centered_cross = cross - sum_z * sum_y / n
    beta = np.linalg.lstsq(centered_gram, centered_cross, rcond=1e-10)[0]
    intercept = (sum_y - sum_z @ beta) / n
    return intercept, beta


def hedge_returns(predicted, raw_returns, market_caps):
    order = np.argsort(predicted, kind="stable")
    decile = max(1, len(order) // 10)
    short = order[:decile]
    long = order[-decile:]
    ew = float(raw_returns[long].mean() - raw_returns[short].mean())
    size = np.maximum(np.asarray(market_caps, dtype=float), 0)
    vw = float(np.average(raw_returns[long], weights=size[long])
               - np.average(raw_returns[short], weights=size[short]))
    return ew, vw, decile


def nw_mean_stats(values, lags=6):
    values = np.asarray(values, dtype=float)
    n = len(values)
    mean = float(values.mean())
    centered = values - mean
    long_run = float(centered @ centered / n)
    for lag in range(1, min(lags, n - 1) + 1):
        covariance = float(centered[lag:] @ centered[:-lag] / n)
        long_run += 2 * (1 - lag / (lags + 1)) * covariance
    t_stat = mean / np.sqrt(long_run / n) if long_run > 0 else None
    sharpe = float(np.sqrt(12) * mean / values.std(ddof=1)) if n > 1 and values.std(ddof=1) > 0 else None
    return {"months": n, "mean_monthly": mean, "sharpe_annualized": sharpe,
            "newey_west_t": float(t_stat) if t_stat is not None else None,
            "positive_month_fraction": float(np.mean(values > 0))}


def block_bootstrap_interval(values, rng, draws=2000, block=12):
    values = np.asarray(values, dtype=float)
    n = len(values)
    starts = rng.integers(0, n, size=(draws, (n + block - 1) // block))
    offsets = np.arange(block)
    indices = (starts[:, :, None] + offsets) % n
    means = values[indices.reshape(draws, -1)[:, :n]].mean(axis=1)
    return np.quantile(means, [0.025, 0.975]).tolist()


def factor_alpha(values, periods, factors, lags=6):
    y = np.asarray(values, dtype=float)
    X = np.column_stack([np.ones(len(y)), np.stack([factors[month] for month in periods])])
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    residual = y - X @ beta
    meat = np.einsum("i,ij,ik->jk", residual * residual, X, X)
    for lag in range(1, min(lags, len(y) - 1) + 1):
        cross = np.einsum("i,ij,ik->jk", residual[lag:] * residual[:-lag],
                          X[lag:], X[:-lag])
        meat += (1 - lag / (lags + 1)) * (cross + cross.T)
    bread = np.linalg.inv(X.T @ X)
    covariance = bread @ meat @ bread
    standard_error = np.sqrt(max(float(covariance[0, 0]), 0))
    return {"alpha_monthly": float(beta[0]),
            "alpha_annualized_simple": float(12 * beta[0]),
            "newey_west_t": float(beta[0] / standard_error) if standard_error > 0 else None}


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--csv", type=Path, default=Path("data/characteristics_data_feb2017.csv"))
    parser.add_argument("--rf-zip", type=Path, default=Path("data/F-F_Research_Data_Factors_CSV.zip"))
    parser.add_argument("--knots", type=int, choices=(9, 14), default=9)
    parser.add_argument("--model", choices=("np", "linear", "linear_rank"), default="np")
    parser.add_argument("--price-filter", choices=("current", "previous"), default="previous",
                        help="previous is tradable; current is a retrospective paper-sample diagnostic")
    parser.add_argument("--bic-df", choices=("full", "local"), default="full")
    parser.add_argument("--bic-grid-steps", type=int, default=48)
    parser.add_argument("--bic-min-fraction", type=float, default=0.001)
    parser.add_argument("--max-iter", type=int, default=50000)
    parser.add_argument("--fixed-features-from", type=Path,
                        help="Use selected_characteristics from an earlier JSON; skip BIC selection")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.bic_grid_steps < 3 or not 0 < args.bic_min_fraction < 1:
        parser.error("BIC grid requires at least 3 steps and 0 < minimum fraction < 1")
    if args.price_filter == "current":
        print("WARNING: current-month price is unavailable when the portfolio is formed; "
              "results are diagnostic, not a tradable backtest.", flush=True)
    else:
        print("Using previous-month price: portfolio eligibility is known at formation.",
              flush=True)
    output = args.output or Path(
        f"results/oos_{args.model}_{args.knots}knots_{args.bic_df}_{args.price_filter}.json")
    features, data = load_data(args.csv, price_filter=args.price_filter)
    periods = data.yy.to_numpy(dtype=np.int32) * 100 + data.mm.to_numpy(dtype=np.int32)
    selection_data = data.loc[periods <= 199012]
    knots = [i / (args.knots + 1) for i in range(1, args.knots + 1)]
    rf = load_risk_free(args.rf_zip)
    factors = read_factors(args.rf_zip)
    center = scale = None
    if args.model == "linear":
        raw = selection_data[features].to_numpy(dtype=np.float64)
        center = raw.mean(axis=0)
        scale = raw.std(axis=0)
        scale[scale == 0] = 1.0
        del raw
    first_grid = second_grid = None
    selection_n, selection_months = len(selection_data), selection_data.groupby(["yy", "mm"]).ngroups
    if args.fixed_features_from:
        chosen = json.loads(args.fixed_features_from.read_text())["selected_characteristics"]
        if not chosen or not set(chosen).issubset(features):
            raise ValueError("Fixed-feature JSON has no valid selected_characteristics")
    else:
        if args.model == "np":
            gram, cross, y2, selection_n, selection_months = sufficient_statistics(
                selection_data, features, knots, "excess", rf)
        else:
            gram, cross, y2, selection_n, selection_months = linear_sufficient_statistics(
                selection_data, features, knots, rf, args.model, center, scale)
        first, first_grid = select_by_bic(gram, cross, y2, selection_n,
                                          np.ones(len(features)), args.max_iter, args.bic_df,
                                          args.bic_grid_steps, args.bic_min_fraction)
        width = len(knots) + 2 if args.model == "np" else 1
        first_norms = np.linalg.norm(first.reshape(len(features), width), axis=1)
        weights = np.full(len(features), np.inf)
        eligible = first_norms > 1e-8
        # Paper equation (6): (sum_k beta_sk^2)^(-1/2) = 1 / ||beta_s||_2.
        weights[eligible] = 1 / first_norms[eligible]
        second, second_grid = select_by_bic(gram, cross, y2, selection_n,
                                            weights, args.max_iter, args.bic_df,
                                            args.bic_grid_steps, args.bic_min_fraction)
        for stage, grid in (("first", first_grid), ("second", second_grid)):
            best = min(grid, key=lambda row: row["bic"])
            if best["relative_kkt_violation"] >= 0.001:
                raise RuntimeError(f"{stage} BIC optimum did not converge; "
                                   "increase --max-iter before trusting the result")
        second_best = min(second_grid, key=lambda row: row["bic"])
        if second_best is second_grid[-1]:
            recent = [row["selected_group_indices"] for row in second_grid[-3:]]
            if recent[0] != recent[1] or recent[1] != recent[2]:
                raise RuntimeError("Selected features change at the BIC grid boundary; "
                                   "extend or refine the penalty grid")
            print("BIC minimum is at the grid edge, but the selected feature set "
                  "is unchanged across the last three penalties.", flush=True)
        chosen = [name for name, norm in zip(features,
                  np.linalg.norm(second.reshape(len(features), width), axis=1)) if norm > 1e-8]
    if not chosen:
        raise RuntimeError("Feature selection returned no predictors; rolling test is unavailable")
    print(f"Pre-1991 selection: {len(chosen)} characteristics: {chosen}", flush=True)

    chosen_index = [features.index(name) for name in chosen]
    chosen_center = center[chosen_index] if center is not None else None
    chosen_scale = scale[chosen_index] if scale is not None else None
    history = deque()
    months = []
    for (year, month), frame in data.groupby(["yy", "mm"], sort=True):
        key = int(year) * 100 + int(month)
        if key < 198101:
            continue
        key, design, raw_returns, excess_returns = month_data(
            frame, chosen, knots, rf, args.model, chosen_center, chosen_scale)
        if key >= 199101:
            if len(history) != 120:
                raise RuntimeError(f"Expected 120 training months before {key}, found {len(history)}")
            intercept, beta = window_coefficients(history, design.shape[1])
            predicted = intercept + design @ beta
            ew, vw, decile = hedge_returns(predicted, raw_returns, frame.lme.to_numpy())
            months.append({"yyyymm": key, "firms": len(frame), "decile_firms": decile,
                           "ew_long_short": ew, "vw_long_short": vw})
            if len(months) % 60 == 0:
                print(f"Predicted {len(months)} out-of-sample months, latest {key}", flush=True)
        history.append(monthly_sums(design, excess_returns))
        if len(history) > 120:
            history.popleft()

    rng = np.random.default_rng(20260924)
    summaries = {}
    for label, start, end in (("full", 199101, 201405), ("1991-2000", 199101, 200012),
                              ("2001-2010", 200101, 201012), ("2011-2014", 201101, 201405)):
        subset = [row for row in months if start <= row["yyyymm"] <= end]
        month_keys = [row["yyyymm"] for row in subset]
        summaries[label] = {}
        for weight, field in (("ew", "ew_long_short"), ("vw", "vw_long_short")):
            returns = [row[field] for row in subset]
            stats = nw_mean_stats(returns)
            stats["block_bootstrap_95pct_mean_ci"] = block_bootstrap_interval(returns, rng)
            stats["ff3_alpha"] = factor_alpha(returns, month_keys, factors)
            summaries[label][weight] = stats

    result = {
        "source_csv": str(args.csv),
        "model": args.model,
        "price_filter": args.price_filter,
        "price_known_at_formation": args.price_filter == "previous",
        "linear_scaling": "pooled pre-1991 mean and standard deviation" if args.model == "linear" else None,
        "knots": args.knots,
        "bic_df": args.bic_df,
        "bic_grid_steps": args.bic_grid_steps,
        "bic_min_fraction": args.bic_min_fraction,
        "selection_period": "1963-07 through 1990-12",
        "selection_observations": selection_n,
        "selection_months": selection_months,
        "selected_characteristics": chosen,
        "fixed_features_from": str(args.fixed_features_from) if args.fixed_features_from else None,
        "stage1_best": min(first_grid, key=lambda item: item["bic"]) if first_grid else None,
        "stage2_best": min(second_grid, key=lambda item: item["bic"]) if second_grid else None,
        "stage1_bic_at_grid_edge": min(first_grid, key=lambda item: item["bic"]) is first_grid[-1] if first_grid else None,
        "stage2_bic_at_grid_edge": min(second_grid, key=lambda item: item["bic"]) is second_grid[-1] if second_grid else None,
        "stage2_edge_support_stable": (
            len({tuple(row["selected_group_indices"]) for row in second_grid[-3:]}) == 1
            if second_grid and min(second_grid, key=lambda item: item["bic"]) is second_grid[-1]
            else None),
        "test_period": "1991-01 through 2014-05",
        "training_window_months": 120,
        "portfolio_rule": "long top 10% predicted returns, short bottom 10%; monthly rebalanced; no transaction costs",
        "summaries": summaries,
        "monthly_returns": months,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(f"Wrote {output}", flush=True)
    for label, summary in summaries.items():
        print(label, "EW", summary["ew"]["mean_monthly"], "Sharpe", summary["ew"]["sharpe_annualized"],
              "VW", summary["vw"]["mean_monthly"], "Sharpe", summary["vw"]["sharpe_annualized"], flush=True)


if __name__ == "__main__":
    main()
