"""Check whether pre-1991 spline selection depends on the BIC penalty grid."""

import argparse
import json
from pathlib import Path

import numpy as np

from run_paper_comparison import load_data, load_risk_free, select_by_bic, sufficient_statistics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path,
                        default=Path("data/characteristics_data_feb2017.csv"))
    parser.add_argument("--rf-zip", type=Path,
                        default=Path("data/F-F_Research_Data_Factors_CSV.zip"))
    parser.add_argument("--price-filter", choices=("current", "previous"), default="previous")
    parser.add_argument("--max-iter", type=int, default=2000)
    parser.add_argument("--output", type=Path,
                        default=Path("results/bic_sensitivity_9knots_previous.json"))
    args = parser.parse_args()

    features, data = load_data(args.csv, price_filter=args.price_filter)
    periods = data.yy.to_numpy(dtype=np.int32) * 100 + data.mm.to_numpy(dtype=np.int32)
    data = data.loc[periods <= 199012]
    knots = [i / 10 for i in range(1, 10)]
    gram, cross, y2, n, months = sufficient_statistics(
        data, features, knots, "excess", load_risk_free(args.rf_zip))
    del data

    configurations = (("standard", 24, 0.001, "full"),
                      ("denser", 48, 0.001, "full"),
                      ("lower_penalty", 30, 0.0003, "full"),
                      ("local_df", 24, 0.001, "local"))
    results = {}
    for label, steps, minimum, df_method in configurations:
        first, grid1 = select_by_bic(gram, cross, y2, n, np.ones(len(features)),
                                     args.max_iter, df_method, steps, minimum)
        norms = np.linalg.norm(first.reshape(len(features), 11), axis=1)
        weights = np.full(len(features), np.inf)
        selected = norms > 1e-8
        weights[selected] = 1 / norms[selected]
        second, grid2 = select_by_bic(gram, cross, y2, n, weights,
                                      args.max_iter, df_method, steps, minimum)
        final_norms = np.linalg.norm(second.reshape(len(features), 11), axis=1)
        best1 = min(grid1, key=lambda row: row["bic"])
        best2 = min(grid2, key=lambda row: row["bic"])
        results[label] = {
            "steps": steps, "minimum_lambda_fraction": minimum, "df_method": df_method,
            "first_features": [name for name, active in zip(features, selected) if active],
            "final_features": [name for name, norm in zip(features, final_norms) if norm > 1e-8],
            "stage1_best": best1, "stage2_best": best2,
            "stage1_at_lower_edge": best1 is grid1[-1],
            "stage2_at_lower_edge": best2 is grid2[-1],
            "stage1_any_nonconverged": any(row["relative_kkt_violation"] >= 0.001 for row in grid1),
            "stage2_any_nonconverged": any(row["relative_kkt_violation"] >= 0.001 for row in grid2),
            "stage1_grid": grid1, "stage2_grid": grid2,
        }
        print(label, len(results[label]["final_features"]), results[label]["final_features"],
              "stage2 edge", results[label]["stage2_at_lower_edge"],
              "KKT", best2["relative_kkt_violation"], flush=True)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"price_filter": args.price_filter,
                                       "selection_observations": n, "selection_months": months,
                                       "configurations": results}, indent=2) + "\n")
    print("Wrote", args.output, flush=True)


if __name__ == "__main__":
    main()
