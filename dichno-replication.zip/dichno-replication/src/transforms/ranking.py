import numpy as np

def rank_transform(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X)
    sorted_x = np.sort(X)
    return (np.searchsorted(sorted_x, X, side="left") + 1) / (len(X) + 1)
