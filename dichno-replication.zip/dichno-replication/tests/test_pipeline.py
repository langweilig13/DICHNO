"""Small invariant checks for the paper-style replication pipeline."""

import unittest
import csv
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from run_oos_validation import make_design, monthly_sums, window_coefficients
from run_paper_comparison import fit_group_lasso, kkt_violation, load_data
from src.model.baseline_model import build_matrix
from src.transforms.ranking import rank_transform


class PipelineTests(unittest.TestCase):
    def test_monthly_ranks_and_spline_basis(self):
        x = np.array([3.0, 1.0, 2.0])
        np.testing.assert_allclose(rank_transform(x), [0.75, 0.25, 0.5])
        basis = build_matrix(x[:, None], [0.5])
        np.testing.assert_allclose(basis[:, 0], 1)
        np.testing.assert_allclose(basis[:, 1], rank_transform(x))
        np.testing.assert_allclose(basis[:, -1], [0.25**2, 0, 0])

    def test_rolling_ols_matches_direct_fit(self):
        rng = np.random.default_rng(7)
        matrices = [rng.normal(size=(12, 3)) for _ in range(4)]
        targets = [1.5 + matrix @ [0.3, -0.2, 0.4] + rng.normal(size=12) * 0.01
                   for matrix in matrices]
        intercept, beta = window_coefficients(
            [monthly_sums(matrix, target) for matrix, target in zip(matrices[:3], targets[:3])], 3)
        direct_x = np.vstack(matrices[:3])
        direct_y = np.concatenate(targets[:3])
        direct = np.linalg.lstsq(np.column_stack([np.ones(len(direct_x)), direct_x]),
                                 direct_y, rcond=None)[0]
        np.testing.assert_allclose(np.r_[intercept, beta], direct, atol=1e-10)

    def test_group_lasso_satisfies_optimality_condition(self):
        rng = np.random.default_rng(9)
        x = rng.normal(size=(100, 8))
        y = x[:, 0] - 0.7 * x[:, 4] + rng.normal(size=100) * 0.2
        x -= x.mean(axis=0)
        y -= y.mean()
        gram = x.T @ x / len(x)
        cross = x.T @ y / len(x)
        weights = np.ones(4)
        beta, _ = fit_group_lasso(gram, cross, 0.1, weights, np.zeros(8), 500)
        self.assertLess(kkt_violation(beta, gram, cross, 0.1, weights), 0.001)

    def test_linear_comparison_uses_raw_values_and_rank_variant_does_not(self):
        frame = pd.DataFrame({"a": [10.0, 20.0, 40.0], "b": [2.0, 1.0, 3.0]})
        raw = make_design(frame, ["a", "b"], [], "linear",
                          np.array([10.0, 1.0]), np.array([10.0, 2.0]))
        ranks = make_design(frame, ["a", "b"], [], "linear_rank")
        np.testing.assert_allclose(raw, [[0, 0.5], [1, 0], [3, 1]])
        np.testing.assert_allclose(ranks, [[0.25, 0.5], [0.5, 0.25], [0.75, 0.75]])

    def test_previous_price_filter_uses_only_prior_month(self):
        metadata = ["row", "yy", "mm", "date", "permno", "ret", "q10", "q20", "q50", "prc"]
        features = [f"feature_{i}" for i in range(36)]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tiny.csv"
            with path.open("w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(metadata + features)
                for month, price in ((7, 4), (8, 6), (9, 4)):
                    writer.writerow([month, 1963, month, f"1963-{month:02d}-31", 10001,
                                     0.1, 0, 0, 0, price] + [1] * 36)
            _, current = load_data(path, "current")
            _, previous = load_data(path, "previous")
        self.assertEqual(current.mm.tolist(), [8])
        self.assertEqual(previous.mm.tolist(), [9])


if __name__ == "__main__":
    unittest.main()
