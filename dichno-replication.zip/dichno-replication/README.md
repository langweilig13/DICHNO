# Репликация: Dissecting Characteristics Nonparametrically

Небольшой воспроизводимый пакет: код оценки моделей, результаты завершённых прогонов и пояснения. Это **приближение** к статье, а не точное воспроизведение оригинальной базы CRSP/Compustat или её таблиц.

- [Итоги каждого законченного этапа и связь «код → результат → вывод»](RESULTS.md)
- [Происхождение данных и ограничения](DATA.md)
- `results/` — полные JSON: параметры, отобранные характеристики, месячные доходности и сводные статистики.
- `run_paper_comparison.py` — отбор характеристик на полной исторической выборке для сравнения с Table 4.
- `run_bic_sensitivity.py` — чувствительность отбора к сетке BIC и определению степеней свободы.
- `run_oos_validation.py` — отбор до 1991 г., 120-месячная скользящая OLS, портфели верхнего/нижнего дециля с 1991 г.; нелинейная и две линейные версии.
- `src/` — модель и преобразование характеристик; `tests/` — проверки ключевых операций.

## Запуск

Проверено с Python 3.14.5, NumPy 2.4.6 и pandas 3.0.3. Из корня этой папки:

```bash
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -q
```

Положите исходный `characteristics_data_feb2017.csv` в `data/` (он не входит в пакет; см. [DATA.md](DATA.md)). Затем для повторения сохранённых прогонов:

```bash
python3 run_paper_comparison.py --knots 9 --output results/paper_comparison_9knots_full_excess.json
python3 run_paper_comparison.py --knots 14 --output results/paper_comparison_14knots_full_excess.json
python3 run_bic_sensitivity.py
python3 run_oos_validation.py
python3 run_oos_validation.py --knots 14
python3 run_oos_validation.py --model linear
python3 run_oos_validation.py --model linear_rank
python3 run_oos_validation.py --bic-df local
```

Прогоны могут занимать заметное время и память. По умолчанию OOS-скрипт использует **цену предыдущего месяца**, известную при формировании портфеля. Ретроспективный фильтр `--price-filter current` не следует интерпретировать как торгуемый бэктест.

Исследуемая статья: [Kozak, Nagel, Santosh — *Dissecting Characteristics Nonparametrically*](https://www.nber.org/papers/w23227). В данном пакете исторический период заканчивается маем 2014 г.; результаты за 2015–2025 гг. здесь отсутствуют.
