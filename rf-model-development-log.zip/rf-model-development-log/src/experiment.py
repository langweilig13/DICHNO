"""Config-driven reproduction of the three model-development attempts."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


SEED = 42
BASE_EXCLUDED = {"Unnamed: 0", "yy", "mm", "date", "permno", "ret"}
BREAKPOINTS = {"q10", "q20", "q50"}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def capped_sample(data, maximum_rows):
    if maximum_rows is None or len(data) <= maximum_rows:
        return data.copy()
    return data.sample(n=maximum_rows, random_state=SEED).copy()


def annualized_sharpe(returns):
    values = pd.Series(returns).replace([np.inf, -np.inf], np.nan).dropna()
    if len(values) < 2 or values.std(ddof=1) <= 0:
        return float("nan")
    return float(np.sqrt(12) * values.mean() / values.std(ddof=1))


def load_and_prepare(path, config):
    columns = pd.read_csv(path, nrows=0).columns.tolist()
    excluded = set(BASE_EXCLUDED)
    if config["exclude_market_breakpoints"]:
        excluded |= BREAKPOINTS
    features = [column for column in columns if column not in excluded]
    required = {"date", "permno", "ret"}
    if not required.issubset(columns):
        raise ValueError(f"Missing columns: {sorted(required - set(columns))}")

    dtypes = {column: "float32" for column in ["ret", *features]}
    dtypes["permno"] = "int64"
    data = pd.read_csv(
        path,
        usecols=["date", "permno", "ret", *features],
        dtype=dtypes,
        low_memory=False,
    )
    data["date"] = pd.to_datetime(data["date"], errors="raise")
    data.sort_values(["permno", "date"], inplace=True, ignore_index=True)
    data.replace([np.inf, -np.inf], np.nan, inplace=True)
    if "prc" in data.columns:
        data["prc"] = data["prc"].abs()

    groups = data.groupby("permno", sort=False)
    data["target_return"] = groups["ret"].shift(-1)
    data["target_date"] = groups["date"].shift(-1)
    current = data["date"].dt.to_period("M")
    following = data["target_date"].dt.to_period("M")
    data = data.loc[(following == current + 1) & data["target_return"].notna()].copy()
    data["target_rank"] = (
        data.groupby("target_date")["target_return"].rank(pct=True, method="average") - 0.5
    ).astype("float32")

    if config["rank_features"]:
        data[features] = (
            data.groupby("date")[features]
            .rank(pct=True, method="average", na_option="keep")
            .astype("float32")
            - 0.5
        )
    return data, features


def time_split(data, shares):
    dates = np.array(sorted(data["date"].unique()))
    first = int(len(dates) * shares[0])
    second = int(len(dates) * (shares[0] + shares[1]))
    train = data[data["date"].isin(dates[:first])].copy()
    validation = data[data["date"].isin(dates[first:second])].copy()
    test = data[data["date"].isin(dates[second:])].copy()
    return train, validation, test


def select_features(train, features, config):
    sample = capped_sample(train, config["selector_sample_rows"])
    params = dict(config.get("selector_rf", config["rf"]))
    forest = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            (
                "model",
                RandomForestRegressor(
                    **params,
                    criterion="squared_error",
                    random_state=SEED,
                    n_jobs=-1,
                ),
            ),
        ]
    )
    forest.fit(sample[features], sample[config["selector_target"]])
    importance = pd.DataFrame(
        {
            "feature": features,
            "importance": forest.named_steps["model"].feature_importances_,
        }
    ).sort_values("importance", ascending=False, ignore_index=True)
    count = min(config["selected_feature_count"], len(importance))
    return importance.head(count)["feature"].tolist(), importance


def create_models(config):
    linear = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", LinearRegression()),
        ]
    )
    if config["model_type"] == "linear":
        return {"linear": linear}

    rf_params = dict(config["rf"])
    random_forest = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            (
                "model",
                RandomForestRegressor(
                    **rf_params,
                    random_state=SEED,
                    n_jobs=-1,
                ),
            ),
        ]
    )
    boosting = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            (
                "model",
                HistGradientBoostingRegressor(
                    learning_rate=0.07,
                    max_iter=100,
                    max_leaf_nodes=15,
                    min_samples_leaf=40,
                    l2_regularization=1.0,
                    random_state=SEED,
                ),
            ),
        ]
    )
    return {"linear": linear, "random_forest": random_forest, "boosting": boosting}


def fit_models(data, selected, config):
    fitting = capped_sample(data, config["training_sample_rows"])
    models = create_models(config)
    for name, model in models.items():
        print(f"Training {name} on {len(fitting):,} rows")
        model.fit(fitting[selected], fitting[config["model_target"]])
    return models


def predict_models(models, data, selected):
    result = pd.DataFrame(
        {
            "signal_date": data["date"].to_numpy(),
            "target_date": data["target_date"].to_numpy(),
            "permno": data["permno"].to_numpy(),
            "actual_return": data["target_return"].to_numpy(),
        }
    )
    for name, model in models.items():
        result[name] = model.predict(data[selected])
        result[name] = (
            result.groupby("target_date")[name].rank(pct=True, method="average") - 0.5
        )
    return result


def build_portfolio(predictions, model_names, weights, quantile, weighting):
    table = predictions.copy()
    table["score"] = sum(
        weight * table[name] for name, weight in zip(model_names, weights)
    )
    table["rank"] = table.groupby("target_date")["score"].rank(pct=True, method="first")
    long = table[table["rank"] >= 1 - quantile].copy()
    short = table[table["rank"] <= quantile].copy()

    if weighting == "equal":
        long["weight"] = 1 / long.groupby("target_date")["rank"].transform("count")
        short["weight"] = 1 / short.groupby("target_date")["rank"].transform("count")
    else:
        long["weight"] = long["rank"] - (1 - quantile) + 1e-6
        short["weight"] = quantile - short["rank"] + 1e-6
        long["weight"] /= long.groupby("target_date")["weight"].transform("sum")
        short["weight"] /= short.groupby("target_date")["weight"].transform("sum")

    long["weighted"] = long["weight"] * long["actual_return"]
    short["weighted"] = short["weight"] * short["actual_return"]
    portfolio = pd.concat(
        [
            long.groupby("target_date")["weighted"].sum().rename("long_return"),
            short.groupby("target_date")["weighted"].sum().rename("short_return"),
            table.groupby("target_date")["actual_return"].mean().rename("market_return"),
        ],
        axis=1,
    ).dropna()
    portfolio["long_short_return"] = portfolio["long_return"] - portfolio["short_return"]
    return portfolio


def volatility_scale(current, history=None):
    history = pd.Series(dtype=float) if history is None else pd.Series(history)
    current = pd.Series(current)
    combined = pd.concat([history, current])
    volatility = combined.shift(1).rolling(12, min_periods=6).std(ddof=1) * np.sqrt(12)
    scale = (0.10 / volatility).clip(0.25, 2.0).fillna(1.0)
    return current * scale.loc[current.index]


def candidate_weights(model_names, count):
    candidates = []
    for index in range(len(model_names)):
        weights = np.zeros(len(model_names))
        weights[index] = 1.0
        candidates.append(weights)
    candidates.append(np.ones(len(model_names)) / len(model_names))
    rng = np.random.default_rng(SEED)
    for _ in range(count):
        candidates.append(rng.dirichlet(np.ones(len(model_names))))
    return candidates


def choose_configuration(predictions, config):
    names = [column for column in predictions.columns if column in {"linear", "random_forest", "boosting"}]
    portfolio_config = config["portfolio"]
    weights_list = candidate_weights(names, portfolio_config["random_ensemble_weights"])
    best = None
    for weights in weights_list:
        for quantile in portfolio_config["quantiles"]:
            for weighting in portfolio_config["weightings"]:
                portfolio = build_portfolio(predictions, names, weights, quantile, weighting)
                for use_scaling in portfolio_config["volatility_scaling"]:
                    returns = (
                        volatility_scale(portfolio["long_short_return"])
                        if use_scaling
                        else portfolio["long_short_return"]
                    )
                    score = annualized_sharpe(returns)
                    if best is None or score > best["validation_sharpe"]:
                        best = {
                            "model_names": names,
                            "weights": weights,
                            "quantile": quantile,
                            "weighting": weighting,
                            "use_scaling": use_scaling,
                            "validation_sharpe": score,
                            "validation_portfolio": portfolio,
                        }
    return best


def plot_outputs(importance, selected, portfolio, output):
    top = importance.head(20).sort_values("importance")
    colors = ["#1565C0" if value in selected else "#B0BEC5" for value in top["feature"]]
    fig, axis = plt.subplots(figsize=(10, 7))
    axis.barh(top["feature"], top["importance"], color=colors)
    axis.set_title("Random Forest feature importance")
    fig.tight_layout()
    fig.savefig(output / "feature_importance.png", dpi=160)
    plt.close(fig)

    columns = ["strategy_return", "long_short_return", "long_return", "market_return"]
    cumulative = (1 + portfolio[columns]).cumprod()
    fig, axis = plt.subplots(figsize=(12, 6))
    cumulative.plot(ax=axis)
    axis.set_title("Test cumulative returns")
    axis.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output / "cumulative_returns.png", dpi=160)
    plt.close(fig)


def main():
    args = parse_args()
    start = time.time()
    config = json.loads(args.config.read_text(encoding="utf-8"))
    args.output.mkdir(parents=True, exist_ok=True)

    data, features = load_and_prepare(args.data, config)
    train, validation, test = time_split(data, config["split"])
    del data
    selected, importance = select_features(train, features, config)
    initial_models = fit_models(train, selected, config)
    validation_predictions = predict_models(initial_models, validation, selected)

    if config["portfolio"]["search_validation"]:
        chosen = choose_configuration(validation_predictions, config)
    else:
        names = list(initial_models)
        chosen = {
            "model_names": names,
            "weights": np.ones(len(names)) / len(names),
            "quantile": config["portfolio"]["quantiles"][0],
            "weighting": config["portfolio"]["weightings"][0],
            "use_scaling": config["portfolio"]["volatility_scaling"][0],
            "validation_sharpe": float("nan"),
            "validation_portfolio": build_portfolio(
                validation_predictions,
                names,
                np.ones(len(names)) / len(names),
                config["portfolio"]["quantiles"][0],
                config["portfolio"]["weightings"][0],
            ),
        }

    full_training = pd.concat([train, validation], ignore_index=True)
    final_models = fit_models(full_training, selected, config)
    test_predictions = predict_models(final_models, test, selected)
    portfolio = build_portfolio(
        test_predictions,
        chosen["model_names"],
        chosen["weights"],
        chosen["quantile"],
        chosen["weighting"],
    )
    if chosen["use_scaling"]:
        portfolio["strategy_return"] = volatility_scale(
            portfolio["long_short_return"],
            chosen["validation_portfolio"]["long_short_return"],
        )
    else:
        portfolio["strategy_return"] = portfolio["long_short_return"]

    test_predictions["ensemble_score"] = sum(
        weight * test_predictions[name]
        for name, weight in zip(chosen["model_names"], chosen["weights"])
    )
    rank_ic = test_predictions.groupby("target_date").apply(
        lambda month: month["ensemble_score"].corr(month["actual_return"], method="spearman")
    ).mean()
    metrics = {
        "experiment": config["name"],
        "runtime_minutes": (time.time() - start) / 60,
        "validation_sharpe": chosen["validation_sharpe"],
        "test_strategy_sharpe": annualized_sharpe(portfolio["strategy_return"]),
        "raw_long_short_sharpe": annualized_sharpe(portfolio["long_short_return"]),
        "long_only_sharpe": annualized_sharpe(portfolio["long_return"]),
        "market_sharpe": annualized_sharpe(portfolio["market_return"]),
        "monthly_rank_ic": float(rank_ic),
        "selected_features": selected,
        "quantile": chosen["quantile"],
        "weighting": chosen["weighting"],
        "volatility_scaling": chosen["use_scaling"],
        "model_weights": {
            name: float(weight)
            for name, weight in zip(chosen["model_names"], chosen["weights"])
        },
    }
    (args.output / "metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )
    importance.to_csv(args.output / "feature_importance.csv", index=False)
    test_predictions.to_csv(args.output / "test_predictions.csv", index=False)
    portfolio.reset_index().to_csv(args.output / "monthly_returns.csv", index=False)
    plot_outputs(importance, selected, portfolio, args.output)
    print(json.dumps(metrics, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
