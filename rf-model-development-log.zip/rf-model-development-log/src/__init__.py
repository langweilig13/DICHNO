"""Reproducible stock-return experiment package."""

