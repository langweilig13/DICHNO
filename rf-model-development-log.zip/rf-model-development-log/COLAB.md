# Запуск в Google Colab

1. Загрузите репозиторий в Colab или клонируйте его.
2. Загрузите CSV в `/content/characteristics_data_feb2017.csv`.
3. Выполните:

```python
!pip -q install -r requirements.txt
!python run_experiment.py \
    --data "/content/characteristics_data_feb2017.csv" \
    --config "configs/attempt_03_fast_ensemble.json" \
    --output "results/reproduction_attempt_03"
```

Для запуска других итераций замените конфиг:

```text
configs/attempt_01_baseline.json
configs/attempt_02_ranked_linear.json
configs/attempt_03_fast_ensemble.json
```

Результаты каждого запуска содержат:

- `metrics.json` — итоговые метрики и параметры;
- `feature_importance.csv` — рейтинг признаков;
- `test_predictions.csv` — прогнозы на test;
- `monthly_returns.csv` — доходности портфелей;
- `feature_importance.png` и `cumulative_returns.png` — графики.

CSV не следует коммитить в GitHub. Он уже исключён через `.gitignore`.

