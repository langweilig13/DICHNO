# Stock-return feature selection: development log

Проверенный по фактически выполненным ячейкам `Untitled45.ipynb` журнал трёх
успешных итераций модели прогнозирования месячной доходности акций:

1. Random Forest для отбора признаков и Linear Regression на исходных признаках.
2. Random Forest и Linear Regression после исключения общерыночных порогов и внутримесячного ранжирования.
3. Быстрый ансамбль Linear Regression, Random Forest и Gradient Boosting после RF-отбора.

Целевая переменная во всех корректных экспериментах — доходность **следующего календарного месяца**. Разделение train/validation/test выполняется по времени.

## Главный результат

| Попытка | Validation Sharpe | Test strategy Sharpe | Raw long-short | Long-only | Market | Rank IC |
|---|---:|---:|---:|---:|---:|---:|
| 1. Baseline RF → Linear | — | 0.1225* | 0.1225 | 0.8544 | 0.6293 | 0.0011 |
| 2. Ranked RF → Linear | 0.6826 | 0.4078 | 0.4078 | 0.4410 | 0.5793 | 0.0141 |
| 3. Fast model search | 1.1428 | 0.7285 | 0.4404 | 0.7015 | 0.6313 | 0.0562 |

\* В первой попытке отдельный `strategy_return` не строился, поэтому в таблице указан long-short Sharpe. Значение выше единицы (`1.1428`) относится к **validation третьей попытки**, а не к финальному test.

Важно: в третьей попытке перебирался ансамбль из трёх моделей, но validation
выбрал веса `linear=0`, `random_forest=0`, `boosting=1`. Итоговая стратегия —
это чистый `HistGradientBoostingRegressor` с volatility scaling, а не смесь
трёх моделей.

Подробный разбор: [docs/EXPERIMENT_REPORT.md](docs/EXPERIMENT_REPORT.md).

## Структура

```text
.
├── configs/                 # Зафиксированные параметры трёх попыток
├── data/README.md           # Куда положить CSV
├── docs/                    # Аналитический отчёт и изображения
├── notebooks/               # Исходный выполненный ноутбук — источник истины
├── results/                 # Сводные исторические метрики
├── src/                     # Общий воспроизводимый пайплайн
├── run_experiment.py        # Точка запуска
├── COLAB.md                 # Запуск в Google Colab
└── requirements.txt
```

## Быстрый запуск

```bash
python -m pip install -r requirements.txt
python run_experiment.py \
  --data "data/characteristics_data_feb2017.csv" \
  --config configs/attempt_03_fast_ensemble.json \
  --output results/reproduction_attempt_03
```

Для Windows PowerShell команда записывается одной строкой:

```powershell
python run_experiment.py --data "data\characteristics_data_feb2017.csv" --config "configs\attempt_03_fast_ensemble.json" --output "results\reproduction_attempt_03"
```

## Важные ограничения

- Исходный CSV не включён: размер около 753 МБ превышает лимит обычного GitHub-файла.
- Между первой успешной попыткой и двумя последующими менялся фактический CSV:
  первая читала `983252 × 43` (485 МБ), последующие — `1404048 × 40`
  (718 МБ). Поэтому изменение Sharpe нельзя приписывать только модели.
- Исторические метрики получены в Colab в ходе разработки. Из-за случайной подвыборки и различий версий библиотек небольшие отклонения при повторном запуске нормальны.
- Все Sharpe рассчитаны из месячных доходностей как `sqrt(12) * mean / std`, без комиссии и при безрисковой ставке, равной нулю.
- Validation используется для выбора конфигурации. Итоговым показателем является только test Sharpe.
- `notebooks/Untitled45_original.ipynb` сохранён без изменений; SHA-256:
  `B20DBE9DC9495C9021D5A0DFDA6E598B4DA3FB35D687072B80DC059FDF44FC91`.

Полная сверка всех шести выполненных ячеек, включая три остановленных запуска:
[docs/NOTEBOOK_AUDIT.md](docs/NOTEBOOK_AUDIT.md).

Точное историческое выполнение находится в исходном ноутбуке. `src/` и
`run_experiment.py` — удобный рефакторинг для новых запусков; они не заменяют
ноутбук при аудите старых результатов.
