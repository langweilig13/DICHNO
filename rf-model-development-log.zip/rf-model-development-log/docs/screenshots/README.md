# Скриншоты экспериментов

- `attempt_01_feature_importance.png` — важность признаков baseline, включая доминирование `q10/q20/q50`.
- `attempt_01_cumulative_returns.png` — накопленные доходности baseline.
- `attempt_02_training_progress.png` — длительное обучение полного варианта ансамбля.
- `attempt_03_final_results.png` — исторический скриншот из отдельного запуска:
  validation Sharpe `1.4288`, test Sharpe `0.7285`. Он **не совпадает** с
  сохранённым выводом `Untitled45.ipynb`, где validation Sharpe равен `1.1428`.
  В основной сводке используется значение из ноутбука.
- `attempt_02_colab_log.txt` — полный сохранённый лог RF-CV и выбора конфигурации второй попытки.

Изображения являются историческими артефактами разработки и не считаются
источником истины при расхождении с ноутбуком. Проверенные числа находятся в
`results/attempts_summary.csv`, а полная сверка — в `docs/NOTEBOOK_AUDIT.md`.
